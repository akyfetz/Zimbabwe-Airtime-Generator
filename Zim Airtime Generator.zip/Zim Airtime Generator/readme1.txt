Permissions:
	Modification
	Distribution
	Private use
	
Limitations:
	Liability
	Warranty
